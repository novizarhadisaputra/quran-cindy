<?php

namespace App\Providers;

use App\Repositories\Api\AuthRepository as ApiAuthRepository;
use App\Repositories\Api\SuratRepository as ApiSuratRepository;
use App\Repositories\Api\AyatRepository as ApiAyatRepository;
use App\Repositories\Api\TafsirRepository as ApiTafsirRepository;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind('repository.api.auth', ApiAuthRepository::class);
        $this->app->bind('repository.api.surat', ApiSuratRepository::class);
        $this->app->bind('repository.api.ayat', ApiAyatRepository::class);
        $this->app->bind('repository.api.tafsir', ApiTafsirRepository::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
